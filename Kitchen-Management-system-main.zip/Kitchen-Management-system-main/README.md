# Kitchen-Management-system
This project simulates a kitchen environment where multiple chefs compete for shared resources (like stoves, knives, and chopping boards) to prepare meals inspired by dining philosophers problem. The simulation demonstrates concurrent programming concepts in C, including thread synchronization, resource management, and deadlock prevention.
